from __future__ import annotations

import copy
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Mapping, MutableMapping, Optional


SUPPORTED_LANGUAGES = ("pt", "en", "es")
DEFAULT_LANGUAGE = "pt"


@dataclass(frozen=True)
class ActionDefinition:
    key: str
    names: Mapping[str, str]
    category: str
    action_type: str
    enabled: bool = True
    allow_while_printing: bool = False
    default_gcode: str = ""
    temperature: Optional[int] = None
    extrusion_mm: Optional[float] = None
    distance_mm: Optional[float] = None
    feedrate: Optional[int] = None
    file_slot: Optional[int] = None
    enclosure_label: Optional[str] = None
    enclosure_status: Optional[bool] = None


ACTION_DEFINITIONS: Dict[str, ActionDefinition] = {
    "pause": ActionDefinition(
        key="pause",
        names={"pt": "Octo Pausar", "en": "Octo Pause", "es": "Octo Pausar"},
        category="print",
        action_type="pause",
        allow_while_printing=True,
    ),
    "resume": ActionDefinition(
        key="resume",
        names={"pt": "Octo Retomar", "en": "Octo Resume", "es": "Octo Reanudar"},
        category="print",
        action_type="resume",
        allow_while_printing=True,
    ),
    "home": ActionDefinition(
        key="home",
        names={"pt": "Octo Home", "en": "Octo Home", "es": "Octo Home"},
        category="movement",
        action_type="gcode",
        default_gcode="G28",
    ),
    "level": ActionDefinition(
        key="level",
        names={
            "pt": "Octo Nivelamento",
            "en": "Octo Leveling",
            "es": "Octo Nivelacion",
        },
        category="movement",
        action_type="gcode",
        default_gcode="G28 X Y Z",
    ),
    "z_up": ActionDefinition(
        key="z_up",
        names={
            "pt": "Octo Subir Eixo Z",
            "en": "Octo Raise Z Axis",
            "es": "Octo Subir Eje Z",
        },
        category="movement",
        action_type="z_move",
        distance_mm=2.0,
        feedrate=600,
    ),
    "z_down": ActionDefinition(
        key="z_down",
        names={
            "pt": "Octo Descer Eixo Z",
            "en": "Octo Lower Z Axis",
            "es": "Octo Bajar Eje Z",
        },
        category="movement",
        action_type="z_move",
        distance_mm=-2.0,
        feedrate=600,
    ),
    "cancel": ActionDefinition(
        key="cancel",
        names={"pt": "Octo Cancelar", "en": "Octo Cancel", "es": "Octo Cancelar"},
        category="print",
        action_type="cancel",
        allow_while_printing=True,
    ),
    "printer_power_on": ActionDefinition(
        key="printer_power_on",
        names={
            "pt": "Octo Ligar Impressora",
            "en": "Octo Printer Power On",
            "es": "Octo Encender Impresora",
        },
        category="enclosure",
        action_type="enclosure_output",
        allow_while_printing=True,
        enclosure_label="Power",
        enclosure_status=True,
    ),
    "light_on": ActionDefinition(
        key="light_on",
        names={
            "pt": "Octo Ligar Luz Impressora",
            "en": "Octo Printer Light On",
            "es": "Octo Encender Luz Impresora",
        },
        category="enclosure",
        action_type="enclosure_output",
        allow_while_printing=True,
        enclosure_label="LIGHT",
        enclosure_status=True,
    ),
    "printer_power_off": ActionDefinition(
        key="printer_power_off",
        names={
            "pt": "Octo Desligar Impressora",
            "en": "Octo Printer Power Off",
            "es": "Octo Apagar Impresora",
        },
        category="enclosure",
        action_type="enclosure_output",
        enclosure_label="Power",
        enclosure_status=False,
    ),
    "print_last": ActionDefinition(
        key="print_last",
        names={
            "pt": "Octo Imprimir Ultimo Arquivo",
            "en": "Octo Print Last File",
            "es": "Octo Imprimir Ultimo Archivo",
        },
        category="print",
        action_type="print_last",
        enabled=False,
    ),
    "retract": ActionDefinition(
        key="retract",
        names={"pt": "Octo Retract", "en": "Octo Retract", "es": "Octo Retraer"},
        category="extruder",
        action_type="extrude",
        extrusion_mm=-5.0,
        feedrate=1800,
    ),
    "extrude": ActionDefinition(
        key="extrude",
        names={"pt": "Octo Extrude", "en": "Octo Extrude", "es": "Octo Extruir"},
        category="extruder",
        action_type="extrude",
        extrusion_mm=5.0,
        feedrate=300,
    ),
    "bed_heat": ActionDefinition(
        key="bed_heat",
        names={
            "pt": "Octo Aquecer Mesa",
            "en": "Octo Heat Bed",
            "es": "Octo Calentar Cama",
        },
        category="temperature",
        action_type="bed_temperature",
        allow_while_printing=True,
        temperature=100,
    ),
    "bed_off": ActionDefinition(
        key="bed_off",
        names={
            "pt": "Octo Desligar Mesa",
            "en": "Octo Bed Off",
            "es": "Octo Apagar Cama",
        },
        category="temperature",
        action_type="gcode",
        allow_while_printing=True,
        default_gcode="M140 S0",
    ),
    "hotend_pla": ActionDefinition(
        key="hotend_pla",
        names={
            "pt": "Octo Aquecer HotEnd PLA",
            "en": "Octo Heat HotEnd PLA",
            "es": "Octo Calentar HotEnd PLA",
        },
        category="temperature",
        action_type="hotend_temperature",
        allow_while_printing=True,
        temperature=200,
    ),
    "hotend_abs": ActionDefinition(
        key="hotend_abs",
        names={
            "pt": "Octo Aquecer HotEnd ABS",
            "en": "Octo Heat HotEnd ABS",
            "es": "Octo Calentar HotEnd ABS",
        },
        category="temperature",
        action_type="hotend_temperature",
        allow_while_printing=True,
        temperature=240,
    ),
    "hotend_petg": ActionDefinition(
        key="hotend_petg",
        names={
            "pt": "Octo Aquecer HotEnd PETG",
            "en": "Octo Heat HotEnd PETG",
            "es": "Octo Calentar HotEnd PETG",
        },
        category="temperature",
        action_type="hotend_temperature",
        allow_while_printing=True,
        temperature=235,
    ),
    "hotend_off": ActionDefinition(
        key="hotend_off",
        names={
            "pt": "Octo Desligar HotEnd",
            "en": "Octo HotEnd Off",
            "es": "Octo Apagar HotEnd",
        },
        category="temperature",
        action_type="gcode",
        allow_while_printing=True,
        default_gcode="M104 S0",
    ),
    "motors_off": ActionDefinition(
        key="motors_off",
        names={
            "pt": "Octo Desligar Motores",
            "en": "Octo Motors Off",
            "es": "Octo Apagar Motores",
        },
        category="movement",
        action_type="gcode",
        default_gcode="M18",
    ),
    "emergency": ActionDefinition(
        key="emergency",
        names={
            "pt": "Octo Emergencia",
            "en": "Octo Emergency",
            "es": "Octo Emergencia",
        },
        category="safety",
        action_type="gcode",
        enabled=False,
        allow_while_printing=True,
        default_gcode="M112\nM104 S0\nM140 S0",
    ),
    "print_piece1": ActionDefinition(
        key="print_piece1",
        names={
            "pt": "Octo Imprimir Peca 1",
            "en": "Octo Print Part 1",
            "es": "Octo Imprimir Pieza 1",
        },
        category="print",
        action_type="print_file",
        enabled=False,
        file_slot=1,
    ),
    "print_piece2": ActionDefinition(
        key="print_piece2",
        names={
            "pt": "Octo Imprimir Peca 2",
            "en": "Octo Print Part 2",
            "es": "Octo Imprimir Pieza 2",
        },
        category="print",
        action_type="print_file",
        enabled=False,
        file_slot=2,
    ),
    "print_piece3": ActionDefinition(
        key="print_piece3",
        names={
            "pt": "Octo Imprimir Peca 3",
            "en": "Octo Print Part 3",
            "es": "Octo Imprimir Pieza 3",
        },
        category="print",
        action_type="print_file",
        enabled=False,
        file_slot=3,
    ),
}


ACTION_ORDER = list(ACTION_DEFINITIONS.keys())


def _action_defaults(definition: ActionDefinition) -> Dict[str, Any]:
    data: Dict[str, Any] = {
        "enabled": definition.enabled,
        "name": "",
        "allow_while_printing": definition.allow_while_printing,
    }
    if definition.default_gcode:
        data["gcode"] = definition.default_gcode
    if definition.temperature is not None:
        data["temperature"] = definition.temperature
    if definition.extrusion_mm is not None:
        data["extrusion_mm"] = definition.extrusion_mm
    if definition.distance_mm is not None:
        data["distance_mm"] = definition.distance_mm
    if definition.feedrate is not None:
        data["feedrate"] = definition.feedrate
    if definition.file_slot is not None:
        data["file_path"] = ""
        data["file_origin"] = "local"
    if definition.enclosure_label is not None:
        data["enclosure_label"] = definition.enclosure_label
    if definition.enclosure_status is not None:
        data["enclosure_status"] = definition.enclosure_status
    return data


def get_default_settings() -> Dict[str, Any]:
    return {
        "enabled": True,
        "language": DEFAULT_LANGUAGE,
        "cancel_requires_arm": True,
        "cancel_arm_seconds": 15,
        "network": {
            "ssdp_enabled": True,
            "ssdp_bind_ip": "0.0.0.0",
            "advertise_host": "",
            "advertise_port": 80,
            "advertise_path": "/",
            "bridge_id": "",
            "uuid": "",
        },
        "debug": {
            "enabled": True,
            "max_events": 100,
            "test_device_enabled": False,
        },
        "runtime": {
            "last_file_path": "",
            "last_file_origin": "local",
        },
        "actions": {
            key: _action_defaults(definition)
            for key, definition in ACTION_DEFINITIONS.items()
        },
    }


def deep_update(base: MutableMapping[str, Any], extra: Mapping[str, Any]) -> MutableMapping[str, Any]:
    for key, value in extra.items():
        if (
            isinstance(value, Mapping)
            and isinstance(base.get(key), MutableMapping)
        ):
            deep_update(base[key], value)
        else:
            base[key] = value
    return base


def merged_settings(stored: Optional[Mapping[str, Any]]) -> Dict[str, Any]:
    data = get_default_settings()
    if stored:
        deep_update(data, copy.deepcopy(stored))
    return data


def language_from_settings(settings: Mapping[str, Any]) -> str:
    language = str(settings.get("language") or DEFAULT_LANGUAGE).lower()
    if language not in SUPPORTED_LANGUAGES:
        return DEFAULT_LANGUAGE
    return language


def action_settings(settings: Mapping[str, Any], action_key: str) -> Dict[str, Any]:
    actions = settings.get("actions") or {}
    merged = _action_defaults(ACTION_DEFINITIONS[action_key])
    if isinstance(actions, Mapping):
        stored = actions.get(action_key) or {}
        if isinstance(stored, Mapping):
            deep_update(merged, stored)
    return merged


def action_name(settings: Mapping[str, Any], action_key: str) -> str:
    definition = ACTION_DEFINITIONS[action_key]
    current = action_settings(settings, action_key)
    custom = str(current.get("name") or "").strip()
    if custom:
        return custom
    language = language_from_settings(settings)
    return definition.names.get(language, definition.names[DEFAULT_LANGUAGE])


def enabled_action_keys(settings: Mapping[str, Any]) -> List[str]:
    keys: List[str] = []
    if not settings.get("enabled", True):
        return keys

    for key in ACTION_ORDER:
        current = action_settings(settings, key)
        if current.get("enabled", False):
            keys.append(key)
    return keys


def build_gcode_for_action(settings: Mapping[str, Any], action_key: str) -> List[str]:
    definition = ACTION_DEFINITIONS[action_key]
    current = action_settings(settings, action_key)

    if definition.action_type == "bed_temperature":
        temp = int(current.get("temperature", definition.temperature or 0))
        return [f"M140 S{temp}"]

    if definition.action_type == "hotend_temperature":
        temp = int(current.get("temperature", definition.temperature or 0))
        return [f"M104 S{temp}"]

    if definition.action_type == "extrude":
        extrusion_mm = float(current.get("extrusion_mm", definition.extrusion_mm or 0))
        feedrate = int(current.get("feedrate", definition.feedrate or 300))
        return ["M83", f"G1 E{extrusion_mm:g} F{feedrate}"]

    if definition.action_type == "z_move":
        distance_mm = float(current.get("distance_mm", definition.distance_mm or 0))
        feedrate = int(current.get("feedrate", definition.feedrate or 600))
        return ["G91", f"G1 Z{distance_mm:g} F{feedrate}", "G90"]

    raw = str(current.get("gcode") or definition.default_gcode or "")
    return split_gcode(raw)


def split_gcode(raw: str) -> List[str]:
    commands: List[str] = []
    for line in raw.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        cleaned = line.strip()
        if cleaned and not cleaned.startswith(";"):
            commands.append(cleaned)
    return commands


def list_action_metadata(settings: Mapping[str, Any]) -> List[Dict[str, Any]]:
    result: List[Dict[str, Any]] = []
    for key in ACTION_ORDER:
        definition = ACTION_DEFINITIONS[key]
        current = action_settings(settings, key)
        result.append(
            {
                "key": key,
                "name": action_name(settings, key),
                "category": definition.category,
                "type": definition.action_type,
                "enabled": bool(current.get("enabled", False)),
                "settings": current,
                "names": dict(definition.names),
            }
        )
    return result


def coerce_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        return value.strip().lower() in ("1", "true", "yes", "on")
    return False


def validate_action_key(action_key: str) -> str:
    if action_key not in ACTION_DEFINITIONS:
        raise KeyError(f"Unknown Alexa OctoPrint action: {action_key}")
    return action_key


def iter_file_action_keys() -> Iterable[str]:
    for key, definition in ACTION_DEFINITIONS.items():
        if definition.action_type == "print_file":
            yield key
