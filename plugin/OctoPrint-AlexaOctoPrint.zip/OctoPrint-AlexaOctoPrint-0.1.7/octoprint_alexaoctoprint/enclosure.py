from __future__ import annotations

from typing import Any, Iterable, Mapping, Optional


def normalize_label(value: Any) -> str:
    return " ".join(str(value or "").split()).casefold()


def find_output_by_label(outputs: Iterable[Any], label: str) -> Optional[Mapping[str, Any]]:
    wanted = normalize_label(label)
    for output in outputs or []:
        if isinstance(output, Mapping) and normalize_label(output.get("label")) == wanted:
            return output
    return None


def hardware_value(status: bool, active_low: bool) -> bool:
    return not bool(status) if active_low else bool(status)
