from __future__ import annotations

from typing import Any, Dict


UPDATE_VERSION_URL = (
    "https://raw.githubusercontent.com/RICLAMER/AlexaOctoPrint/"
    "main/plugin/version.json"
)
UPDATE_PACKAGE_URL = (
    "https://raw.githubusercontent.com/RICLAMER/AlexaOctoPrint/"
    "main/plugin/OctoPrint-AlexaOctoPrint.zip"
)


def build_update_information(identifier: str, display_name: str, current_version: str) -> Dict[str, Any]:
    return {
        identifier: {
            "displayName": display_name,
            "displayVersion": current_version,
            "type": "jsondata",
            "current": current_version,
            "jsondata": UPDATE_VERSION_URL,
            "pip": UPDATE_PACKAGE_URL,
        }
    }
