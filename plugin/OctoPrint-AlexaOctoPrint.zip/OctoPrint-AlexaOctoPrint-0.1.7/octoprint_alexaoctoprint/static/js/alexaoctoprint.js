$(function () {
    function AlexaOctoPrintViewModel(parameters) {
        var self = this;

        self.settings = parameters[0];
        self.debugStatus = ko.observable(null);
        self.files = ko.observableArray([{ label: "-", path: "" }]);
        self.actionList = ko.observableArray([]);
        self.emptySetting = ko.observable();

        self.pluginSettings = function () {
            return self.settings.settings.plugins.alexaoctoprint;
        };

        self.actionSetting = function (action, key) {
            var pluginSettings = self.pluginSettings();
            if (!pluginSettings || !pluginSettings.actions || !pluginSettings.actions[action.key]) {
                return self.emptySetting;
            }
            if (pluginSettings.actions[action.key][key] === undefined) {
                return self.emptySetting;
            }
            return pluginSettings.actions[action.key][key];
        };

        self.hasSetting = function (action, key) {
            var pluginSettings = self.pluginSettings();
            return !!(
                pluginSettings &&
                pluginSettings.actions &&
                pluginSettings.actions[action.key] &&
                pluginSettings.actions[action.key][key] !== undefined
            );
        };

        self.refreshDebug = function () {
            return OctoPrint.simpleApiCommand("alexaoctoprint", "debug_status", {})
                .done(function (response) {
                    self.debugStatus(response);
                    if (response.actions) {
                        self.actionList(response.actions);
                    }
                });
        };

        self.reloadSsdp = function () {
            return OctoPrint.simpleApiCommand("alexaoctoprint", "reload_ssdp", {})
                .done(function () {
                    self.refreshDebug();
                });
        };

        self.refreshFiles = function () {
            return OctoPrint.simpleApiCommand("alexaoctoprint", "list_files", {})
                .done(function (response) {
                    var options = [{ label: "-", path: "" }];
                    _.each(response.files || [], function (file) {
                        options.push({
                            label: file.origin + ": " + file.name,
                            path: file.path,
                            origin: file.origin
                        });
                    });
                    self.files(options);
                });
        };

        self.runAction = function (action) {
            return OctoPrint.simpleApiCommand("alexaoctoprint", "run_action", { action: action.key })
                .done(function (response) {
                    new PNotify({
                        title: response.ok ? "AlexaOctoPrint" : "AlexaOctoPrint error",
                        text: response.message || response.error || action.key,
                        type: response.ok ? "success" : "error",
                        hide: true
                    });
                    self.refreshDebug();
                });
        };

        self.onBeforeBinding = function () {
            self.refreshDebug();
            self.refreshFiles();
        };
    }

    OCTOPRINT_VIEWMODELS.push({
        construct: AlexaOctoPrintViewModel,
        dependencies: ["settingsViewModel"],
        elements: ["#settings_plugin_alexaoctoprint"]
    });
});
